<?php
$arr = [];
$product = 1;
$evenSum = 0;
$oddSum = 0;

// Создаем 20 случайных чисел
for ($i = 0; $i < 20; $i++) {
    $arr[] = rand(1, 20);
}

echo '<table style="border-collapse:collapse;">';

foreach ($arr as $number) {
    echo '<tr><td style="border:1px solid black;padding:8px;">' . $number . '</td></tr>';

    $product *= $number;

    if ($number % 2 == 0) {
        $evenSum += $number;
    } else {
        $oddSum += $number;
    }
}
echo '</table>';

echo '<p>Произведение целых чисел: ' . $product . '</p>';
echo '<p>Сумма четных чисел: ' . $evenSum . '</p>';
echo '<p>Сумма нечетных чисел: ' . $oddSum . '</p>';
?>
