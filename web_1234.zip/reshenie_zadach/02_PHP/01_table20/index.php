<?php
// Создаем таблицу 20 на 20
echo '<table style="border-collapse:collapse;">';
$number = 1;

for ($i = 0; $i < 20; $i++) {
    echo '<tr>';
    for ($j = 0; $j < 20; $j++) {
        // Шахматный цвет
        $color = (($i + $j) % 2 == 0) ? '#eeeeee' : '#999999';

        // Второстепенная диагональ: i + j = 19
        if ($i + $j == 19) {
            $color = '#ff9900';
        }

        echo '<td style="width:30px;height:30px;text-align:center;border:1px solid black;background:' . $color . ';">';
        echo $number;
        echo '</td>';
        $number++;
    }
    echo '</tr>';
}
echo '</table>';
?>
