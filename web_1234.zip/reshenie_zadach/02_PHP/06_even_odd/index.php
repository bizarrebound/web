<?php
// Создаем массив из 20 случайных чисел
$arr = [];
for ($i = 0; $i < 20; $i++) {
    $arr[] = rand(0, 100);
}

echo '<table style="border-collapse:collapse;">';

foreach ($arr as $number) {
    // Для четного числа желтый фон, для нечетного серый
    $color = ($number % 2 == 0) ? 'yellow' : 'gray';

    echo '<tr><td style="border:1px solid black;padding:10px;background:' . $color . ';">';
    echo $number;
    echo '</td></tr>';
}
echo '</table>';
?>
