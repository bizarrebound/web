<?php
$arr = [
    ['name' => 'user1', 'age' => 30, 'salary' => 1000],
    ['name' => 'user2', 'age' => 31, 'salary' => 2000],
    ['name' => 'user3', 'age' => 32, 'salary' => 3000]
];

echo '<table style="border-collapse:collapse;">';
echo '<tr><th>Имя</th><th>Возраст</th><th>Зарплата</th></tr>';

foreach ($arr as $user) {
    echo '<tr>';
    echo '<td style="border:1px solid black;padding:8px;">' . $user['name'] . '</td>';
    echo '<td style="border:1px solid black;padding:8px;">' . $user['age'] . '</td>';
    echo '<td style="border:1px solid black;padding:8px;">' . $user['salary'] . '</td>';
    echo '</tr>';
}
echo '</table>';

// Суммируем зарплаты первого и третьего пользователя
$sum = $arr[0]['salary'] + $arr[2]['salary'];

echo '<p>Сумма зарплат user1 и user3: ' . $sum . '</p>';
?>
