<?php
$arr = [
    ['a', 'b'], ['c', 'd'], ['e', 'f'],
    ['g', 'h'], ['i', 'j'], ['k', 'l']
];

// Закругляем внешние углы таблицы через CSS
echo '<style>
table { border-collapse: separate; border-spacing: 0; overflow:hidden; border:1px solid black; border-radius:15px; }
td { border-right:1px solid black; border-bottom:1px solid black; padding:15px; }
</style>';

echo '<table>';

foreach ($arr as $row) {
    echo '<tr>';
    foreach ($row as $value) {
        echo '<td>' . htmlspecialchars($value) . '</td>';
    }
    echo '</tr>';
}
echo '</table>';
?>
