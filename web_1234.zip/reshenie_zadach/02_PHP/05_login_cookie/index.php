<?php
// При отправке формы сохраняем введенные данные
if (isset($_POST['send'])) {
    setcookie('username', $_POST['username'], time() + 60 * 60 * 24 * 30);
    setcookie('password', $_POST['password'], time() + 60 * 60 * 24 * 30);

    // Для текущего запроса показываем введенные значения
    $username = $_POST['username'];
    $password = $_POST['password'];
} else {
    // Если форму еще не отправляли, читаем данные из куки
    $username = $_COOKIE['username'] ?? '';
    $password = $_COOKIE['password'] ?? '';
}
?>
<form method="post">
    <!-- Поле имени пользователя -->
    <input type="text" name="username" value="<?php echo htmlspecialchars($username); ?>" placeholder="Имя">
    <br><br>

    <!-- Поле пароля -->
    <input type="password" name="password" value="<?php echo htmlspecialchars($password); ?>" placeholder="Пароль">
    <br><br>

    <button type="submit" name="send">Отправить</button>
</form>
