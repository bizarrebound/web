<?php
// Получаем размеры таблицы из адресной строки
$rows = isset($_GET['rows']) ? (int)$_GET['rows'] : 20;
$cols = isset($_GET['cols']) ? (int)$_GET['cols'] : 20;

if ($rows < 1) $rows = 1;
if ($cols < 1) $cols = 1;

$number = 1;
echo '<table style="border-collapse:collapse;">';

for ($i = 0; $i < $rows; $i++) {
    echo '<tr>';
    for ($j = 0; $j < $cols; $j++) {
        $color = (($i + $j) % 2 == 0) ? '#eeeeee' : '#999999';

        // Выделяем второстепенную диагональ только для квадратной таблицы
        if ($rows == $cols && $i + $j == $rows - 1) {
            $color = '#ff9900';
        }

        echo '<td style="width:30px;height:30px;text-align:center;border:1px solid black;background:' . $color . ';">';
        echo $number++;
        echo '</td>';
    }
    echo '</tr>';
}
echo '</table>';
?>
