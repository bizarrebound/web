<?php
$txt = 'Дай, Джим, на счастье лапу мне.';

// Гласные буквы
$vowels = 'аеёиоуыэюяАЕЁИОУЫЭЮЯ';

// Перебираем строку по символам
$chars = preg_split('//u', $txt, -1, PREG_SPLIT_NO_EMPTY);

foreach ($chars as $char) {
    if (mb_strpos($vowels, $char) !== false) {
        // Гласные красные и в два раза больше
        echo '<span style="color:red;font-size:40px;">' . htmlspecialchars($char) . '</span>';
    } elseif (preg_match('/[А-Яа-яЁё]/u', $char)) {
        // Согласные синие
        echo '<span style="color:blue;font-size:20px;">' . htmlspecialchars($char) . '</span>';
    } else {
        echo htmlspecialchars($char);
    }
}
?>
