<?php
// Автоматически создаем 10 гиперссылок
for ($size = 2; $size <= 11; $size++) {
    echo '<a href="?size=' . $size . '">Таблица ' . $size . 'x' . $size . '</a><br>';
}

if (isset($_GET['size'])) {
    $size = (int)$_GET['size'];

    if ($size >= 2 && $size <= 11) {
        echo '<h3>Таблица ' . $size . 'x' . $size . '</h3>';
        echo '<table style="border-collapse:collapse;">';

        $number = 1;
        for ($i = 0; $i < $size; $i++) {
            echo '<tr>';
            for ($j = 0; $j < $size; $j++) {
                echo '<td style="border:1px solid black;padding:10px;">';
                echo $number++;
                echo '</td>';
            }
            echo '</tr>';
        }
        echo '</table>';
    }
}
?>
