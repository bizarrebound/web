CREATE DATABASE IF NOT EXISTS students CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE students;

CREATE TABLE cars (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    color VARCHAR(50) NOT NULL,
    price DECIMAL(10,2) NOT NULL
);

CREATE TABLE people (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    age INT NOT NULL,
    hair_color VARCHAR(50) NOT NULL
);

CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    quantity INT NOT NULL,
    price DECIMAL(10,2) NOT NULL
);

CREATE TABLE images (
    id INT AUTO_INCREMENT PRIMARY KEY,
    url VARCHAR(500) NOT NULL
);

CREATE TABLE links (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    url VARCHAR(500) NOT NULL
);

CREATE TABLE grades (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(200) NOT NULL,
    subject VARCHAR(100) NOT NULL,
    grade DECIMAL(4,2) NOT NULL
);

CREATE TABLE cell_colors (
    id INT AUTO_INCREMENT PRIMARY KEY,
    row_num INT NOT NULL,
    col_num INT NOT NULL,
    color VARCHAR(50) NOT NULL
);

CREATE TABLE messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    date DATETIME NOT NULL,
    text TEXT NOT NULL,
    autor VARCHAR(100) NOT NULL
);

INSERT INTO images (url) VALUES
('https://picsum.photos/id/10/400/250'),
('https://picsum.photos/id/20/400/250'),
('https://picsum.photos/id/30/400/250');

INSERT INTO links (title, url) VALUES
('Google', 'https://www.google.com/'),
('Wikipedia', 'https://www.wikipedia.org/');

INSERT INTO people (name, age, hair_color) VALUES
('Иван', 20, 'brown'), ('Анна', 21, 'blond'), ('Петр', 22, 'black');

INSERT INTO products (name, quantity, price) VALUES
('Товар 1', 3, 100), ('Товар 2', 5, 200), ('Товар 3', 2, 500);

INSERT INTO grades (full_name, subject, grade) VALUES
('Иванов Иван', 'Математика', 5), ('Петров Петр', 'Программирование', 3),
('Сидоров Сидор', 'Базы данных', 4), ('Иванов Иван', 'Физика', 2);

INSERT INTO cell_colors (row_num, col_num, color) VALUES
(0,0,'red'),(0,1,'blue'),(0,2,'yellow'),(0,3,'green'),(0,4,'pink'),
(1,0,'white'),(1,1,'orange'),(1,2,'purple'),(1,3,'cyan'),(1,4,'gray');

INSERT INTO messages (date, text, autor) VALUES
(NOW(), 'Первое сообщение', 'Иван'),
(DATE_SUB(NOW(), INTERVAL 1 DAY), 'Второе сообщение', 'Петр'),
(DATE_SUB(NOW(), INTERVAL 2 DAY), 'Третье сообщение', 'Анна'),
(DATE_SUB(NOW(), INTERVAL 3 DAY), 'Четвертое сообщение', 'Сергей'),
(DATE_SUB(NOW(), INTERVAL 4 DAY), 'Пятое сообщение', 'Олег'),
(DATE_SUB(NOW(), INTERVAL 5 DAY), 'Шестое сообщение', 'Иван'),
(DATE_SUB(NOW(), INTERVAL 6 DAY), 'Седьмое сообщение', 'Петр'),
(DATE_SUB(NOW(), INTERVAL 7 DAY), 'Восьмое сообщение', 'Анна'),
(DATE_SUB(NOW(), INTERVAL 8 DAY), 'Девятое сообщение', 'Сергей'),
(DATE_SUB(NOW(), INTERVAL 9 DAY), 'Десятое сообщение', 'Олег');
