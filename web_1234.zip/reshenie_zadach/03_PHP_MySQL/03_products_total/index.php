<?php
$pdo = new PDO('mysql:host=localhost;dbname=students;charset=utf8mb4', 'root', '');
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Получаем все товары
$rows = $pdo->query('SELECT name, quantity, price FROM products');

$total = 0;
echo '<table style="border-collapse:collapse;">';
echo '<tr><th>Название</th><th>Количество</th><th>Цена</th></tr>';

while ($row = $rows->fetch(PDO::FETCH_ASSOC)) {
    echo '<tr>';
    echo '<td style="border:1px solid black;padding:8px;">' . htmlspecialchars($row['name']) . '</td>';
    echo '<td style="border:1px solid black;padding:8px;">' . $row['quantity'] . '</td>';
    echo '<td style="border:1px solid black;padding:8px;">' . $row['price'] . '</td>';
    echo '</tr>';

    // Общая стоимость товара = количество * цена
    $total += $row['quantity'] * $row['price'];
}
echo '</table>';

echo '<p>Общая стоимость товара: ' . $total . '</p>';
?>
