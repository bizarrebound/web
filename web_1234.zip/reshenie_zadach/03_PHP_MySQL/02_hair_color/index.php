<?php
$pdo = new PDO('mysql:host=localhost;dbname=students;charset=utf8mb4', 'root', '');
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$color = $_GET['color'] ?? '';
?>
<form method="get">
    <select name="color">
        <option value="blond">Блондин</option>
        <option value="brown">Шатен</option>
        <option value="black">Брюнет</option>
        <option value="red">Рыжий</option>
    </select>
    <button>Отправить</button>
</form>

<?php
if ($color != '') {
    // Выбираем людей с указанным цветом волос
    $stmt = $pdo->prepare('SELECT name, age, hair_color FROM people WHERE hair_color = ?');
    $stmt->execute([$color]);

    echo '<table style="border-collapse:collapse;">';
    echo '<tr><th>Имя</th><th>Возраст</th><th>Цвет волос</th></tr>';

    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        echo '<tr>';
        foreach ($row as $value) {
            echo '<td style="border:1px solid black;padding:8px;">' . htmlspecialchars($value) . '</td>';
        }
        echo '</tr>';
    }
    echo '</table>';
}
?>
