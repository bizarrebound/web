<?php
$pdo = new PDO('mysql:host=localhost;dbname=students;charset=utf8mb4', 'root', '');
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Находим среднюю оценку по всей таблице
$average = $pdo->query('SELECT AVG(grade) FROM grades')->fetchColumn();

// Получаем все записи
$rows = $pdo->query('SELECT id, full_name, subject, grade FROM grades');

echo '<p>Средняя оценка: ' . round($average, 2) . '</p>';
echo '<table style="border-collapse:collapse;">';
echo '<tr><th>ID</th><th>ФИО</th><th>Предмет</th><th>Оценка</th></tr>';

while ($row = $rows->fetch(PDO::FETCH_ASSOC)) {
    // Оценки ниже средней выделяем желтым
    $color = ($row['grade'] < $average) ? 'yellow' : 'white';

    echo '<tr style="background:' . $color . ';">';
    foreach ($row as $value) {
        echo '<td style="border:1px solid black;padding:8px;">' . htmlspecialchars($value) . '</td>';
    }
    echo '</tr>';
}
echo '</table>';
?>
