<?php
$pdo = new PDO('mysql:host=localhost;dbname=students;charset=utf8mb4', 'root', '');
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Получаем все адреса картинок
$images = $pdo->query('SELECT url FROM images')->fetchAll(PDO::FETCH_COLUMN);

// Выбираем случайную картинку
$image = $images[array_rand($images)];

// Создаем случайный цвет фона
$background = sprintf('#%06X', mt_rand(0, 0xFFFFFF));
?>
<!DOCTYPE html>
<html lang="ru">
<body style="background:<?php echo $background; ?>;">
    <img src="<?php echo htmlspecialchars($image); ?>" alt="Случайная картинка">
</body>
</html>
