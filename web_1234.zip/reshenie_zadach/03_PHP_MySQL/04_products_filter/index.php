<?php
$pdo = new PDO('mysql:host=localhost;dbname=students;charset=utf8mb4', 'root', '');
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$maxPrice = isset($_GET['max_price']) ? (float)$_GET['max_price'] : 0;
?>
<form method="get">
    <input name="max_price" type="number" step="0.01" placeholder="Максимальная цена" required>
    <button>Показать</button>
</form>

<?php
if (isset($_GET['max_price'])) {
    $rows = $pdo->query('SELECT name, quantity, price FROM products');

    echo '<table style="border-collapse:collapse;">';
    echo '<tr><th>Название</th><th>Количество</th><th>Цена</th></tr>';

    while ($row = $rows->fetch(PDO::FETCH_ASSOC)) {
        // Зеленый фон для цены ниже максимальной, красный для остальных
        $color = ($row['price'] < $maxPrice) ? 'lightgreen' : 'lightcoral';

        echo '<tr style="background:' . $color . ';">';
        echo '<td style="border:1px solid black;padding:8px;">' . htmlspecialchars($row['name']) . '</td>';
        echo '<td style="border:1px solid black;padding:8px;">' . $row['quantity'] . '</td>';
        echo '<td style="border:1px solid black;padding:8px;">' . $row['price'] . '</td>';
        echo '</tr>';
    }
    echo '</table>';
}
?>
