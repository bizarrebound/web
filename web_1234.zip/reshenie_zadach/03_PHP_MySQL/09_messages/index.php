<?php
$pdo = new PDO('mysql:host=localhost;dbname=students;charset=utf8mb4', 'root', '');
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// По ссылке определяем, что показывать
$mode = $_GET['mode'] ?? 'date';

if ($mode == 'length') {
    // Пять самых длинных сообщений
    $sql = 'SELECT date, text, autor FROM messages ORDER BY CHAR_LENGTH(text) DESC LIMIT 5';
} else {
    // Пять самых новых сообщений
    $sql = 'SELECT date, text, autor FROM messages ORDER BY date DESC LIMIT 5';
}
?>
<a href="?mode=date">5 последних сообщений</a><br>
<a href="?mode=length">5 самых длинных сообщений</a>

<?php
$rows = $pdo->query($sql);

echo '<table style="border-collapse:collapse;">';
echo '<tr><th>Дата</th><th>Текст</th><th>Автор</th></tr>';

while ($row = $rows->fetch(PDO::FETCH_ASSOC)) {
    echo '<tr>';
    foreach ($row as $value) {
        echo '<td style="border:1px solid black;padding:8px;">' . htmlspecialchars($value) . '</td>';
    }
    echo '</tr>';
}
echo '</table>';
?>
