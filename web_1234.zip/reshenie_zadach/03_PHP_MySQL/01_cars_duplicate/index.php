<?php
// Подключение к базе MySQL
$pdo = new PDO('mysql:host=localhost;dbname=students;charset=utf8mb4', 'root', '');
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$message = '';

if (isset($_POST['save'])) {
    $name = $_POST['name'];
    $color = $_POST['color'];
    $price = (float)$_POST['price'];

    // Проверяем, есть ли точно такая запись
    $check = $pdo->prepare(
        'SELECT COUNT(*) FROM cars WHERE name = ? AND color = ? AND price = ?'
    );
    $check->execute([$name, $color, $price]);

    if ($check->fetchColumn() > 0) {
        $message = 'Дублирование данных';
    } else {
        $insert = $pdo->prepare(
            'INSERT INTO cars (name, color, price) VALUES (?, ?, ?)'
        );
        $insert->execute([$name, $color, $price]);
        $message = 'Автомобиль сохранен';
    }
}
?>
<form method="post">
    <input name="name" placeholder="Название автомобиля" required><br><br>
    <input name="color" placeholder="Цвет" required><br><br>
    <input name="price" type="number" step="0.01" placeholder="Цена" required><br><br>
    <button name="save">Сохранить</button>
</form>
<p><?php echo $message; ?></p>
