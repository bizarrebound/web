<?php
$pdo = new PDO('mysql:host=localhost;dbname=students;charset=utf8mb4', 'root', '');
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Количество ссылок заранее неизвестно, поэтому используем цикл
$rows = $pdo->query('SELECT title, url FROM links');

echo '<ul>';

while ($row = $rows->fetch(PDO::FETCH_ASSOC)) {
    echo '<li>';
    echo '<a href="' . htmlspecialchars($row['url']) . '">';
    echo htmlspecialchars($row['title']);
    echo '</a>';
    echo '</li>';
}

echo '</ul>';
?>
