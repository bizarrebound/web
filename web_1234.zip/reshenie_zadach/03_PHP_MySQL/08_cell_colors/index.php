<?php
$pdo = new PDO('mysql:host=localhost;dbname=students;charset=utf8mb4', 'root', '');
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Цвет каждой ячейки берется из базы
$rows = $pdo->query('SELECT row_num, col_num, color FROM cell_colors');

echo '<table style="border-collapse:collapse;">';

while ($row = $rows->fetch(PDO::FETCH_ASSOC)) {
    echo '<td style="width:60px;height:60px;border:1px solid black;background:'
        . htmlspecialchars($row['color']) . ';">';
    echo '</td>';

    // После каждого пятого столбца начинаем новую строку
    if ((int)$row['col_num'] == 4) {
        echo '</tr><tr>';
    }
}

echo '</table>';
?>
