РЕШЕНИЯ ЗАДАЧ ПО JAVASCRIPT, PHP И PHP + MYSQL

ВАЖНО:
1. JavaScript/HTML/CSS задачи можно открывать непосредственно через index.html.
2. PHP-задачи требуют локального PHP-сервера (например, XAMPP/OpenServer).
3. Для PHP + MySQL сначала импортируйте файл:
   03_PHP_MySQL/database.sql
   в MySQL/phpMyAdmin.
4. В файлах PHP по умолчанию указано:
   host=localhost
   database=students
   user=root
   password=''
   Если у вас другие данные MySQL, измените строку подключения.

Код специально написан простым способом, без сложных фреймворков.
Важные элементы снабжены комментариями.

Примечание:
Для картинок в JavaScript используются URL сервиса picsum.photos.
Для задачи 5 третьего раздела картинки берутся уже из базы данных.
